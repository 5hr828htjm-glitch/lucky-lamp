LUCKY LAMP REELS — rebuilt iPhone game

Open index.html in a browser to play.
For an installable full-screen iPhone Home Screen app, host index.html over HTTPS
and then use Safari > Share > Add to Home Screen.

This is a browser game prototype, not a signed native App Store app.
No real-money betting, prizes, or gambling features.
